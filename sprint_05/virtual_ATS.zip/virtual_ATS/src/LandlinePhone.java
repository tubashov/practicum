public class LandlinePhone extends Phone {

    public LandlinePhone(String number) {
        super(number);
    }
}
