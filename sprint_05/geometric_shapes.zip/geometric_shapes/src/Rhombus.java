public class Rhombus extends Parallelogram {
    public Rhombus(double a, double b) {
        super(a, b);
    }
}
