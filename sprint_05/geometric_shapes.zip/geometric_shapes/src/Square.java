public class Square extends Rectangle {
    Square(double a) {
        super(a, a);
    }
}
