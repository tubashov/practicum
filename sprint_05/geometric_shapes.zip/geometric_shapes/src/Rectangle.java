public class Rectangle extends Parallelogram {
    public Rectangle(double a, double b) {
        super(a, b);
    }
}
