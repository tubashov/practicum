package task_manager_05.util;

public enum Status {
    NEW,
    IN_PROGRESS,
    DOWN
}
